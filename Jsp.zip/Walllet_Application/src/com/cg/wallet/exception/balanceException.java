package com.cg.wallet.exception;

public class balanceException extends RuntimeException{

	public balanceException(String msg)
	{
		super(msg);
	}
}
